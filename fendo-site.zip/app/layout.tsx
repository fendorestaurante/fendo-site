import "./globals.css";
export const metadata={title:"Fendo — Cocina de territorio y creación",description:"Taberna de tapas y raciones, y Mesa de creación en Huesca."};
export default function RootLayout({children}:{children:React.ReactNode}){return(<html lang="es"><body>{children}</body></html>);}
